package com.capgemini.bookstore.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.Assert;
import org.junit.Before;

import com.capgemini.bookstore.bean.CategoryBean;
import com.capgemini.bookstore.dao.CategoryDao;
import com.capgemini.bookstore.exception.CategoryException;

public class CategoryDaoTest {

	CategoryDao dao = null;

	@Before
	public void setUp() throws Exception {
		dao = new CategoryDao();
	}

	@After
	public void tearDown() throws Exception {
		dao = null;
	}

	@Test
	public void testAddProduct() {

		CategoryBean product = new CategoryBean("Advanture");

		try {
			int genId = dao.addCategoryDetails(product);
			assertNotNull(genId);
		} catch (CategoryException e) {

		}
	}

	/*@Test
	public void testAddProductNull() {

		CategoryBean product = new CategoryBean("");

		try {
			int genId = dao.addCategoryDetails(product);
			assertNull(genId);
		} catch (CategoryException e) {

		}
	}*/

}
