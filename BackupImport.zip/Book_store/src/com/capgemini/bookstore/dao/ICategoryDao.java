package com.capgemini.bookstore.dao;

import java.sql.SQLException;

import com.capgemini.bookstore.bean.CategoryBean;
import com.capgemini.bookstore.exception.CategoryException;

public interface ICategoryDao {
	public void getCategoryDetails(int id);
	//public boolean validate();
	 public int addCategoryDetails(CategoryBean PBobj) throws CategoryException;
	 public void retriveAll();
	 public void deleteCategoryDetails(String id1) throws CategoryException;
	 public void editCategoryDetails(String id2, String cname);
	 public int isValidId(String id1) throws CategoryException, SQLException;
}
