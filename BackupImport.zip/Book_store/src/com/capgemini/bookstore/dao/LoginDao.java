package com.capgemini.bookstore.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import com.capgemini.bookstore.exception.CategoryException;
import com.capgemini.bookstore.utility.CommonCon;

public class LoginDao {
 Scanner sc=new Scanner(System.in);
	public boolean validate() {
		// TODO Auto-generated method stub
	
		PreparedStatement pst;
	    Connection cn;
	    ResultSet rs;
	    try {
	    cn=CommonCon.getInstance().getConnection();
		Statement stmt = cn.createStatement();
		pst=cn.prepareStatement(QueryMapper.LOGIN_QUERY);
		System.out.println("****Book_Store****");
		System.out.println("\nEnter Email :");
		String email=sc.next();
		pst.setString(1, email);
		System.out.println("Enter password :");
		String password=sc.next();
		pst.setString(2, password);
		rs=pst.executeQuery();
		while(rs.next())
		{
			return true;
		}
		return false;

	}
	catch (Exception e)
	{
		e.printStackTrace();
	}
		return false;
}}
