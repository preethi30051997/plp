package com.capgemini.bookstore.utility;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.bookstore.exception.CategoryException;

import oracle.jdbc.pool.OracleDataSource;

public class CommonCon {
	
	private static Connection conn = null;
	private static CommonCon instance = null;
	private static Properties props = null;
	private static OracleDataSource dataSource = null;
	

	private CommonCon() throws CategoryException {
	
		try {
			props = loadProperties();
			dataSource = prepareDataSource();
		} catch (IOException e) {
			
			throw new CategoryException(
					" Could not read the database details from properties file ");
			
		} catch (SQLException e) {
			throw new CategoryException(e.getMessage());
		}

	}

	
	
	public static CommonCon getInstance() throws CategoryException {
		synchronized (CommonCon.class) {
			if (instance == null) {
				instance = new CommonCon();
			}
		}
		return instance;
	}
	
	
	public Connection getConnection() throws CategoryException {
		try {

			conn = dataSource.getConnection();

		} catch (SQLException e) {
			
			throw new CategoryException(" Database connection problem");
		}
		return conn;
	}
	
	
	
	private Properties loadProperties() throws IOException {

		if (props == null) {
			Properties newProps = new Properties();
			String fileName = "resources/jdbc.properties";

			InputStream inputStream = new FileInputStream(fileName);
			newProps.load(inputStream);

			inputStream.close();

			return newProps;
		} else {
			return props;
		}
	}


	
	
	private OracleDataSource prepareDataSource() throws SQLException {

		if (dataSource == null) {
			if (props != null) {
				String connectionURL = props.getProperty("dburl");
				String username = props.getProperty("username");
				String password = props.getProperty("password");

				dataSource = new OracleDataSource();

				dataSource.setURL(connectionURL);
				dataSource.setUser(username);
				dataSource.setPassword(password);
			}
		}
		return dataSource;
	}


    }






	/*static Connection c;
	public  static Connection getCon() throws ClassNotFoundException {
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			 c=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe",
					"system","9999");
			System.out.println("connected");
		}
		catch(SQLException e)
		{
			System.out.println(e);
		}
		return c;
		
	}*/


